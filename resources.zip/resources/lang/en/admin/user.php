<?php

return [
    'exceptions' => [
        'user_has_servers' => 'アカウントにアクティブなサーバーが紐づいているユーザーは削除できません。続行する前に、そのユーザーのサーバーを削除してください。',
    ],
    'notices' => [
        'account_created' => 'アカウントが正常に作成されました。',
        'account_updated' => 'アカウントが正常に更新されました。',
    ],
];